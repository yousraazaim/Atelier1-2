def fibo(n):
    if n==0:
        return 1
    if n==1:
        return 1
    else:
        return (fibo(n-1)+fibo(n-2))
nbr=int(input("entrer un nombre :"))#on demande à l'utilisateur d'entrer un nombre
for i in range (nbr) :
    print(fibo(i),end="")
