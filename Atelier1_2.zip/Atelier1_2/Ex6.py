def tri_bull(tab1,n):
    for i in range(n):
        for j in range(n-i-1):
            if (tab1[j]>tab1[j+1]):
                tab1[j],tab1[j+i]=tab1[j+1],tab1[j]

 def tri_selection(tab2,n):
     for i in range(0,n-1):
         min=i
         for j in range(i+1,n):
             if tab2[j]<tab2[min]:
                 min=j
                 tab2[i],tab2[min]=tab2[min],tab2[i]

