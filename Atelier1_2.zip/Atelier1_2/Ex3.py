def somme(n):
    if(n==1):
        return 1
    else:
        return n+somme(n-1)
nbr=int(input("entrer un nombre:"))#on demande à l'utilisateur d'entrer un nombre
print(somme(nbr))