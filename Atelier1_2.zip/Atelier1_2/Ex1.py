def fct(n):
    if n==0:
        return 1
    else:
        return (n*fct(n-1))
somme=0
for n in range(1,6):
    somme=somme+fct(n)/n
nbr=int(input("veuillez entrer un nombre:"))#on demande à l'utilisateur d'entrer un nombre
print(fct(nbr))

