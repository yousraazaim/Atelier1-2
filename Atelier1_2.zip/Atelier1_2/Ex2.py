def fct(n):
    if (n>1):
        fct(n//2)
        print(n%2,end='')# la fonction end pour afficher le résultat sur la meme ligne
nbr=int(input("entrer un nombre décimal:"))#on demande à l'utilisateur d'entrer un nombre
fct(nbr)
