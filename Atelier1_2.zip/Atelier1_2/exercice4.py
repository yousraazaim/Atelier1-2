s1={23,42,65,57,78,83,29}
s2={57,83,29,67,73,43,48}
s3=s1.intersection(s2)
for val in s3:
    s1.remove(val)
print('l\'intersection est:', s3)
print('s1 après suppression est :',s1)
