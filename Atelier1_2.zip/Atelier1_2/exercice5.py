L1=[47,64,69,37,76,83,95,97]
L2=[]
dict={'yassine':47,'imane':69,'Mohammed':76,'Abir':97}
for val in L1:
    if val in dict.values():
        L2.append(val)
print('la liste est:',L2)#pour afficher la liste obtenue