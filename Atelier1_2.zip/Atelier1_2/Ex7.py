def inverser(ch1):
    res=""
    for caractere in ch1:
        res= caractere + res
    return res
x="yousra"
print(inverser(x))