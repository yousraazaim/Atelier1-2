def tri_selection(tab):
    for i in range(0,len(tab)-1):
        min=i
        for j in range(i+1,len(tab)):
            if tab[j]<tab[min]:
                min=j
        tab[i],tab[min]=tab[min],tab[i]


import array as arr
T=arr.array('i',[5,0,1,-1,2,3,4])
tri_selection(T)
for i in range(0,len(T)):
    print(T[i],end=' ')

