def frequence(chaine,c):
    cmp=0
    for val in chaine:
        if val==c:
            cmp=cmp+1
    return cmp
ch="yousraazaim"
print(frequence(ch,'a'))