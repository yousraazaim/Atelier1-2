def tri_bull(tab):
    b=True #hypothèse le tableau n'est pas trié
    while(b):
        b=False #on suppose que le tableau est trié
        for i in range(0,len(tab)-1):
            if(tab[i]>tab[i+1]):
                tab[i],tab[i+1]=tab[i+1],tab[i]
                b=True

import array as arr
T=arr.array('i',[5,0,1,-1,2,3,4])
tri_bull(T)
for i in range(0,len(T)):
    print(T[i],end=' ')