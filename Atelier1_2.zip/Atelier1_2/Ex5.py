def nbre_chiffre(n):
    if(n//10==0):#// pour effectuer la divison entière
        return 1
    else:
        return 1+nbre_chiffre(n//10)
a=int(input("enter un nombre:"))#on demande à l'utilisateur d'entrer un nombre
print(nbre_chiffre(a))